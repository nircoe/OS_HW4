
hussam's tests :D

if you have permissions problems with scripts, you can do: "chmod u+x run_tests.sh" in terminal.
to test your "malloc_1.cpp": run "./run_tests1.sh" in terminal
to test your "malloc_2.cpp": run "./run_tests.sh" in terminal

if you want to write tests you are welcome :D, and if you think
there's a problem with the tests you can msg me.
