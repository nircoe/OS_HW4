
#! /bin/bash

g++ -std=c++11 ./hussam_tests/main1.cpp -o test_prog
./test_prog
rm ./test_prog